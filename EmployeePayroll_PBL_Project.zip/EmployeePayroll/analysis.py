from collections import defaultdict


def salary_analysis(employees, payroll_records):
    latest_pay = {}
    for record in payroll_records:
        latest_pay[record["emp_id"]] = float(record["net_salary"])

    department_totals = defaultdict(float)
    department_counts = defaultdict(int)
    salaries = []

    for employee in employees:
        salary = latest_pay.get(employee["emp_id"], 0.0)
        department_totals[employee["department"]] += salary
        department_counts[employee["department"]] += 1
        if salary > 0:
            salaries.append(salary)

    return {
        "department_totals": dict(department_totals),
        "department_counts": dict(department_counts),
        "salaries": salaries,
        "average_salary": sum(salaries) / len(salaries) if salaries else 0.0,
        "minimum_salary": min(salaries) if salaries else 0.0,
        "maximum_salary": max(salaries) if salaries else 0.0
    }
