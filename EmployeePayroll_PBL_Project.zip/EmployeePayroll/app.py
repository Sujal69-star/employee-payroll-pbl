import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

from employee import PermanentEmployee, ContractEmployee, Intern, employee_from_dict
from storage import load_employees, save_employees, load_payroll, save_payroll
from analysis import salary_analysis

st.set_page_config(page_title="PayrollPro | Employee Payroll", page_icon="💼", layout="wide")

st.markdown("""
<style>
.main {background-color: #f7f9fc;}
[data-testid="stMetric"] {
    background: white; padding: 16px; border-radius: 12px;
    border: 1px solid #e6eaf0;
}
</style>
""", unsafe_allow_html=True)

st.title("💼 PayrollPro")
st.caption("Employee Payroll Management System | Python • Streamlit • Matplotlib")

@st.cache_data(ttl=2)
def get_data():
    try:
        return load_employees(), load_payroll(), None
    except ValueError as error:
        return [], [], str(error)

employees, payroll, load_error = get_data()
if load_error:
    st.error(load_error)
    st.info("Fix the invalid text file or rename it to let the application create a fresh one.")
    st.stop()

# Use dictionaries for employee records and a set for unique departments.
employee_records = {item["emp_id"]: item for item in employees}
departments = sorted({item["department"] for item in employees})
designations = EmployeeDesignations = ("Junior", "Associate", "Senior", "Manager")
grades = ("A", "B", "C", "D")

latest_pay = {}
for record in payroll:
    latest_pay[record["emp_id"]] = record

total_payroll = sum(float(latest_pay[e["emp_id"]]["net_salary"])
                    for e in employees if e["emp_id"] in latest_pay)
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Employees", len(employees))
col2.metric("Departments", len(departments))
col3.metric("Latest Net Payroll", f"₹{total_payroll:,.0f}")
col4.metric("Payroll Records", len(payroll))

st.sidebar.title("Navigation")
page = st.sidebar.radio("Open module", [
    "Dashboard", "Employee Management", "Payroll Processing",
    "Salary Analysis", "Visualizations", "Data & Downloads"
])

if page == "Dashboard":
    st.subheader("Welcome to your payroll dashboard")
    st.write("Use the sidebar to manage employees, process payroll, and generate reports.")
    if employees:
        view = []
        for e in employees:
            pay = latest_pay.get(e["emp_id"], {})
            view.append({
                "Employee ID": e["emp_id"], "Name": e["name"],
                "Department": e["department"], "Type": e["employee_type"],
                "Latest Net Salary (₹)": float(pay.get("net_salary", 0))
            })
        st.dataframe(pd.DataFrame(view), use_container_width=True, hide_index=True)
    else:
        st.info("No employees yet. Open Employee Management to add your first employee.")

elif page == "Employee Management":
    st.subheader("Module 1 — Employee Management")
    with st.form("add_employee", clear_on_submit=True):
        a, b = st.columns(2)
        emp_id = a.text_input("Employee ID", placeholder="e.g. E001")
        name = b.text_input("Full name")
        c, d = st.columns(2)
        department = c.text_input("Department", placeholder="e.g. IT")
        employee_type = d.selectbox("Employee type", [
            "PermanentEmployee", "ContractEmployee", "Intern"
        ])
        e, f, g = st.columns(3)
        designation = e.selectbox("Designation (fixed tuple)", designations)
        grade = f.selectbox("Grade (fixed tuple)", grades)
        basic_salary = g.number_input("Basic monthly salary (₹)", min_value=0.0, step=1000.0)
        submitted = st.form_submit_button("Add employee", type="primary")
        if submitted:
            try:
                if emp_id.strip() in employee_records:
                    raise ValueError("That Employee ID already exists.")
                cls = {
                    "PermanentEmployee": PermanentEmployee,
                    "ContractEmployee": ContractEmployee,
                    "Intern": Intern
                }[employee_type]
                obj = cls(emp_id, name, department, designation, grade, basic_salary)
                employees.append(obj.to_dict())
                save_employees(employees)
                st.cache_data.clear()
                st.success(f"Employee {name} added and saved to employees.txt.")
                st.rerun()
            except (ValueError, OSError) as error:
                st.error(str(error))

    st.markdown("#### Current employees")
    if employees:
        st.dataframe(pd.DataFrame(employees), use_container_width=True, hide_index=True)
        with st.form("delete_employee"):
            ids = [e["emp_id"] for e in employees]
            delete_id = st.selectbox("Select employee ID to delete", ids)
            confirm = st.checkbox("I confirm this employee should be deleted")
            delete_submit = st.form_submit_button("Delete employee")
            if delete_submit:
                if confirm:
                    employees = [e for e in employees if e["emp_id"] != delete_id]
                    save_employees(employees)
                    st.cache_data.clear()
                    st.success("Employee deleted. Previous payroll history is retained.")
                    st.rerun()
                else:
                    st.warning("Tick the confirmation box first.")
    else:
        st.info("Employee list is empty.")

elif page == "Payroll Processing":
    st.subheader("Module 2 — Payroll Processing")
    if not employees:
        st.info("Add an employee first.")
    else:
        selected_id = st.selectbox(
            "Choose employee", [e["emp_id"] for e in employees],
            format_func=lambda x: f"{x} — {employee_records[x]['name']}"
        )
        employee_data = employee_records[selected_id]
        obj = employee_from_dict(employee_data)
        salary = obj.calculate_salary()  # Polymorphism: each subclass calculates differently.
        st.write(f"**Employee:** {obj.name}  |  **Type:** {type(obj).__name__}")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Basic Salary", f"₹{obj.basic_salary:,.2f}")
        c2.metric("Allowances", f"₹{salary['allowances']:,.2f}")
        c3.metric("Deductions", f"₹{salary['deductions']:,.2f}")
        c4.metric("Net Salary", f"₹{salary['net_salary']:,.2f}")
        st.caption("Sample project rules: Permanent = 20% + 10% allowances, 5% deduction; Contract = 8% allowance, 3% deduction; Intern = no additional allowance or deduction. These are configurable demonstration rules, not legal payroll advice.")
        if st.button("Generate and save payroll record", type="primary"):
            record = {
                "emp_id": obj.emp_id, "name": obj.name,
                "department": obj.department, "employee_type": type(obj).__name__,
                "basic_salary": obj.basic_salary, "allowances": salary["allowances"],
                "deductions": salary["deductions"], "gross_salary": salary["gross_salary"],
                "net_salary": salary["net_salary"],
                "pay_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            payroll.append(record)
            try:
                save_payroll(payroll)
                st.cache_data.clear()
                st.success("Payroll record saved to payroll.txt.")
                st.rerun()
            except OSError as error:
                st.error(f"Could not save payroll: {error}")

    st.markdown("#### Payroll history")
    if payroll:
        st.dataframe(pd.DataFrame(payroll).sort_values("pay_date", ascending=False),
                     use_container_width=True, hide_index=True)
    else:
        st.info("No payroll records yet.")

elif page == "Salary Analysis":
    st.subheader("Module 4 — Salary Analysis")
    report = salary_analysis(employees, payroll)
    a, b, c = st.columns(3)
    a.metric("Average net salary", f"₹{report['average_salary']:,.2f}")
    b.metric("Minimum net salary", f"₹{report['minimum_salary']:,.2f}")
    c.metric("Maximum net salary", f"₹{report['maximum_salary']:,.2f}")
    if report["department_totals"]:
        df = pd.DataFrame([
            {"Department": dep, "Employee Count": report["department_counts"][dep],
             "Net Salary Expenditure (₹)": amount}
            for dep, amount in report["department_totals"].items()
        ])
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.download_button("Download salary analysis CSV", df.to_csv(index=False).encode("utf-8"),
                           "salary_analysis.csv", "text/csv")
    else:
        st.info("Generate payroll records to see salary analysis.")

elif page == "Visualizations":
    st.subheader("Module 5 — Matplotlib Visualizations")
    report = salary_analysis(employees, payroll)
    latest_salaries = [
        float(latest_pay[e["emp_id"]]["net_salary"])
        for e in employees if e["emp_id"] in latest_pay
    ]
    if not payroll or not latest_salaries:
        st.info("Add employees and generate payroll records. Charts will use saved payroll data.")
    else:
        totals = report["department_totals"]
        counts = report["department_counts"]

        st.markdown("#### 1. Department-wise salary expenditure")
        fig1, ax1 = plt.subplots()
        ax1.bar(list(totals.keys()), list(totals.values()))
        ax1.set_ylabel("Net salary expenditure (₹)")
        ax1.set_xlabel("Department")
        ax1.set_title("Department-wise Net Salary Expenditure")
        ax1.tick_params(axis="x", rotation=25)
        fig1.tight_layout()
        st.pyplot(fig1)
        plt.close(fig1)

        st.markdown("#### 2. Salary distribution")
        fig2, ax2 = plt.subplots()
        ax2.hist(latest_salaries, bins=min(10, max(3, len(latest_salaries))))
        ax2.set_xlabel("Latest net salary (₹)")
        ax2.set_ylabel("Number of employees")
        ax2.set_title("Distribution of Latest Net Salaries")
        fig2.tight_layout()
        st.pyplot(fig2)
        plt.close(fig2)

        st.markdown("#### 3. Employee count by department")
        fig3, ax3 = plt.subplots()
        ax3.bar(list(counts.keys()), list(counts.values()))
        ax3.set_ylabel("Number of employees")
        ax3.set_xlabel("Department")
        ax3.set_title("Employee Count by Department")
        ax3.tick_params(axis="x", rotation=25)
        fig3.tight_layout()
        st.pyplot(fig3)
        plt.close(fig3)

elif page == "Data & Downloads":
    st.subheader("Module 3 — File Management")
    st.write("The application reads and updates `employees.txt` and `payroll.txt` in JSON text format.")
    st.write("Missing files are treated as empty lists; malformed files show a clear error instead of silently overwriting data.")
    a, b = st.columns(2)
    a.download_button("Download employees.txt", open("employees.txt", "rb").read() if __import__("os").path.exists("employees.txt") else "[]",
                      "employees.txt", "text/plain")
    b.download_button("Download payroll.txt", open("payroll.txt", "rb").read() if __import__("os").path.exists("payroll.txt") else "[]",
                      "payroll.txt", "text/plain")
    if employees:
        st.download_button("Download employee records CSV",
                           pd.DataFrame(employees).to_csv(index=False).encode("utf-8"),
                           "employees.csv", "text/csv")
    if payroll:
        st.download_button("Download payroll history CSV",
                           pd.DataFrame(payroll).to_csv(index=False).encode("utf-8"),
                           "payroll_history.csv", "text/csv")

st.sidebar.divider()
st.sidebar.caption("PBL Demo • Store no real sensitive employee information in a public demo.")
