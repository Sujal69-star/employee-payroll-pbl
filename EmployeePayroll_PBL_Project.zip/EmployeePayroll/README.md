# Employee Payroll Management System

A beginner-friendly Python PBL website built with Streamlit, text-file storage, inheritance, polymorphism, salary analysis, and Matplotlib charts.

## Files
- `app.py`: Streamlit interface and modules
- `employee.py`: Employee base class and PermanentEmployee, ContractEmployee, Intern subclasses
- `storage.py`: load/save employee and payroll records to text files
- `analysis.py`: department totals, employee counts, average, minimum and maximum salary
- `employees.txt`: created/updated automatically
- `payroll.txt`: created/updated automatically
- `requirements.txt`: required Python packages

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Community Cloud
1. Upload all project files to a GitHub repository.
2. Open https://share.streamlit.io/ and sign in.
3. Choose **Create app**, select your repository and branch, and set the main file to `app.py`.
4. Deploy. Streamlit will provide a shareable URL.

## Important hosting note
Text files satisfy the assignment requirement, but the local filesystem on hosted app services may reset or be replaced during restarts/redeployments. Download backups regularly. For guaranteed persistent multi-user production storage, use a persistent volume or external storage service, while retaining text-file export for the PBL requirement.

## Demonstration salary rules
These are sample rules for educational demonstration only:
- Permanent: 20% + 10% allowances; 5% deduction
- Contract: 8% allowance; 3% deduction
- Intern: no extra allowance or deduction

Adjust these percentages to match the rules specified by your teacher.
