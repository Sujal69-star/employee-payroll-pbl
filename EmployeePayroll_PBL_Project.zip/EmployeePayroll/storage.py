import json
from pathlib import Path

EMPLOYEE_FILE = Path("employees.txt")
PAYROLL_FILE = Path("payroll.txt")


def load_records(path):
    """Load a JSON list from a text file; return an empty list if it is missing."""
    try:
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, list):
            raise ValueError(f"{path} must contain a list of records.")
        return data
    except FileNotFoundError:
        return []
    except (json.JSONDecodeError, ValueError) as error:
        raise ValueError(f"Could not read {path}: {error}") from error


def save_records(path, records):
    """Save records as readable text (JSON) in a .txt file."""
    with open(path, "w", encoding="utf-8") as file:
        json.dump(records, file, indent=4, ensure_ascii=False)


def load_employees():
    return load_records(EMPLOYEE_FILE)


def save_employees(records):
    save_records(EMPLOYEE_FILE, records)


def load_payroll():
    return load_records(PAYROLL_FILE)


def save_payroll(records):
    save_records(PAYROLL_FILE, records)
