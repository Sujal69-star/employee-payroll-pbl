class Employee:
    DESIGNATIONS = ("Junior", "Associate", "Senior", "Manager")
    GRADES = ("A", "B", "C", "D")

    def __init__(self, emp_id, name, department, designation, grade, basic_salary):
        self.emp_id = str(emp_id).strip()
        self.name = str(name).strip()
        self.department = str(department).strip()
        self.designation = designation
        self.grade = grade
        self.basic_salary = float(basic_salary)

        if not self.emp_id or not self.name or not self.department:
            raise ValueError("Employee ID, name, and department are required.")
        if self.basic_salary < 0:
            raise ValueError("Basic salary cannot be negative.")
        if self.designation not in self.DESIGNATIONS:
            raise ValueError("Choose a valid designation.")
        if self.grade not in self.GRADES:
            raise ValueError("Choose a valid grade.")

    def calculate_salary(self):
        raise NotImplementedError("Subclasses must define salary calculation.")

    def to_dict(self):
        return {
            "emp_id": self.emp_id,
            "name": self.name,
            "department": self.department,
            "designation": self.designation,
            "grade": self.grade,
            "basic_salary": self.basic_salary,
            "employee_type": type(self).__name__
        }


class PermanentEmployee(Employee):
    def calculate_salary(self):
        allowances = [self.basic_salary * 0.20, self.basic_salary * 0.10]
        deductions = [self.basic_salary * 0.05]
        gross = self.basic_salary + sum(allowances)
        return {
            "allowances": sum(allowances),
            "deductions": sum(deductions),
            "gross_salary": gross,
            "net_salary": gross - sum(deductions)
        }


class ContractEmployee(Employee):
    def calculate_salary(self):
        allowances = [self.basic_salary * 0.08]
        deductions = [self.basic_salary * 0.03]
        gross = self.basic_salary + sum(allowances)
        return {
            "allowances": sum(allowances),
            "deductions": sum(deductions),
            "gross_salary": gross,
            "net_salary": gross - sum(deductions)
        }


class Intern(Employee):
    def calculate_salary(self):
        allowances = [0.0]
        deductions = [0.0]
        gross = self.basic_salary + sum(allowances)
        return {
            "allowances": sum(allowances),
            "deductions": sum(deductions),
            "gross_salary": gross,
            "net_salary": gross - sum(deductions)
        }


def employee_from_dict(record):
    classes = {
        "PermanentEmployee": PermanentEmployee,
        "ContractEmployee": ContractEmployee,
        "Intern": Intern
    }
    cls = classes.get(record.get("employee_type"), Employee)
    return cls(
        record["emp_id"], record["name"], record["department"],
        record["designation"], record["grade"], float(record["basic_salary"])
    )
